/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author KIEU VIET PHUOC
 */
public class Department {
    private String idDe;
    private String nameDe;
    private int numberEmployee;

    public Department() {
    }

    public Department(String idDe, String nameDe, int numberEmployee) {
        this.idDe = idDe;
        this.nameDe = nameDe;
        this.numberEmployee = numberEmployee;
    }

    public String getIdDe() {
        return idDe;
    }

    public String getNameDe() {
        return nameDe;
    }

    public int getNumberEmployee() {
        return numberEmployee;
    }

    public void setIdDe(String idDe) {
        this.idDe = idDe;
    }

    public void setNameDe(String nameDe) {
        this.nameDe = nameDe;
    }

    public void setNumberEmployee(int numberEmployee) {
        this.numberEmployee = numberEmployee;
    }

    @Override
    public String toString() {
        return this.idDe + "            | " + this.nameDe + "               | "+ this.numberEmployee;
    }
    
    
}
