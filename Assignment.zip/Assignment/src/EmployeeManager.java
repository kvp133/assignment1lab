
import java.util.ArrayList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author KIEU VIET PHUOC
 */
public class EmployeeManager {
    public static void main(String[] args) {
        ArrayList<Department> listDepartment;
        ArrayList<Employee> listEmployee;
        ArrayList<Manager> listManager;
        System.out.println("1. Display list employee of company");
        System.out.println("2. Display list department of company");
        System.out.println("3. Display list employee follow each department");
        System.out.println("4. Display list add new employee to company");
        System.out.println("5. Search information employee as name or id");
        System.out.println("6. Display table salary of all company");
        System.out.println("7. Display table salary of employee assending");
        System.out.println("0. Exit");
        
    }
}
