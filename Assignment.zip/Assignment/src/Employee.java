/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author KIEU VIET PHUOC
 */
public class Employee extends Staff implements ICalculator{
    private int timeWork;

    public Employee() {
    }

    public Employee(int timeWork) {
        this.timeWork = timeWork;
    }

    public Employee(int timeWork, String id, String name, int age, double hsl, String dateWork, String major, int days) {
        super(id, name, age, hsl, dateWork, major, days);
        this.timeWork = timeWork;
    }

    
    @Override
    public double calculateSalary(){
        return super.getHsl() * 3000000 + this.timeWork*200000;
    }
    @Override
    void displayInformation() {
        System.out.println(super.getId()+"          | "+super.getName()+"       | "+super.getAge()+"        | " + super.getHsl()+ "         | " + super.getDateWork()+"             | "+ super.getDays()+"              | "+super.getMajor()+"                          | "+this.timeWork+"                             | "+this.calculateSalary() );
    }
    
}
