/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author KIEU VIET PHUOC
 */
public abstract class Staff {

    private String id;
    private String name;
    private int age;
    private double hsl;
    private String dateWork;
    private String major;
    private int days;

    public Staff() {
    }

    public Staff(String id, String name, int age, double hsl, String dateWork, String major, int days) {
        this.id = id;
        this.name = name;
        this.age = age;
        this.hsl = hsl;
        this.dateWork = dateWork;
        this.major = major;
        this.days = days;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public double getHsl() {
        return hsl;
    }

    public int getAge() {
        return age;
    }

    public String getDateWork() {
        return dateWork;
    }

    public String getMajor() {
        return major;
    }

    public int getDays() {
        return days;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setHsl(double hsl) {
        this.hsl = hsl;
    }

    public void setDateWork(String dateWork) {
        this.dateWork = dateWork;
    }

    public void setMajor(String major) {
        this.major = major;
    }

    public void setDays(int days) {
        this.days = days;
    }

    public void setAge(int age) {
        this.age = age;
    }

    abstract void displayInformation();

}
