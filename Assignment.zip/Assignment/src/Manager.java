/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author KIEU VIET PHUOC
 */
public class Manager extends Staff implements ICalculator{
    private String office;

    public Manager() {
    }

    public Manager(String office) {
        this.office = office;
    }

    public Manager(String office, String id, String name, int age, double hsl, String dateWork, String major, int days) {
        super(id, name, age, hsl, dateWork, major, days);
        this.office = office;
    }
    
    @Override
    void displayInformation() {
        System.out.println("");
    }

    @Override
    public double calculateSalary() {
        double sum = 0;
        if ("Business Leader".equals(this.office))
            sum = super.getHsl()*5000000 + 8000000;
        if ("Project Leader".equals(this.office))
            sum = super.getHsl()*5000000 + 5000000;
        if ("Technical Leader".equals(this.office))
            sum = super.getHsl()*5000000 + 6000000;
        return sum;
    }
    
}
